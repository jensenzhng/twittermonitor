const mongoose = require('mongoose');
const { findOneAndDelete } = require('./models/user');
const User = require('./models/user')

let dbURI = 'mongodb+srv://jensenzhng:a3tewj2005@twittermonitor.ogqg1.mongodb.net/monitor-info?retryWrites=true&w=majority'

module.exports = class mongodb {
    constructor() {}

    async connect() {
        return new Promise((res, rej) => {
            mongoose.connect(dbURI, { useNewUrlParser: true, useUnifiedTopology: true, useFindAndModify: false })
                .then(result => {
                    res('connected');
                })
                .catch(err => console.log(err));
        })
    }

    async fetchUsers(monitor, bot) {
        User.findById({ _id: '601f5a3511b1a49c53b46f6c' }).then(res => {
            console.log(res)
            monitor.usersRequesting = res.usersRequesting;
            monitor.channel = bot.channels.get(res.channel);
        })
    }

    async updateChannel(monitor, channel) {
        User.findOneAndUpdate({ channel: monitor.channel.id }, { channel: channel })
            .then(() => {
                console.log('updated!');
            });

        User.findById({ _id: '601f5a3511b1a49c53b46f6c' }).then(res => {
            console.log(res);
        })
    }

    async updateUsers(monitor, newList) {
        User.findOneAndUpdate({ usersRequesting: monitor.usersRequesting }, { usersRequesting: newList })
            .then(() => {
                console.log('updated!');
            });

        User.findById({ _id: '601f5a3511b1a49c53b46f6c' }).then(res => {
            console.log(res);
        })
    }
}